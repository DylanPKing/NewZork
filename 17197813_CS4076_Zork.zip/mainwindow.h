#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QPlainTextEdit>

#include "Character.h"
#include "Command.h"
#include "Item.h"
#include "weapon.h"
#include "Location.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_westButton_clicked();

    void on_northButton_clicked();

    void on_southButton_clicked();

    void on_EastButton_clicked();

    void on_tpButton_clicked();

private:
    Ui::MainWindow *ui;

    Location *currentLoc;
    Character playerCharacter;
    QVector <Location*> locations;
    bool processCommand(Command&);
    void createLocations();
    void go(QString);
    void printWelcome();
    void teleport();
    void showMap();
};

#endif // MAINWINDOW_H
