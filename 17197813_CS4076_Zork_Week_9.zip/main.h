#ifndef MAIN_H
#define MAIN_H

#include "ZorkCore.h"

class main
{
public:
    main();
};

#endif // MAIN_H
